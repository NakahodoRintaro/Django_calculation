from django.apps import AppConfig


class MycalcConfig(AppConfig):
    name = 'basic_calc'
